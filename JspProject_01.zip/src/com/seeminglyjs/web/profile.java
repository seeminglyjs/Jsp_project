package com.seeminglyjs.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/pro")
public class profile extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html charset=UTF-8;" );
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		
		String ser_ = request.getParameter("ser");	
		String ser = "";
		
		if(ser_.equals("���")) {
			ser = "���";
		}else if(ser_.equals("�з�")) {
			ser = "�з�";
		}else{
			ser= "index";
		}
		
		out.write("ser.html");
		
		
	
	}
}
